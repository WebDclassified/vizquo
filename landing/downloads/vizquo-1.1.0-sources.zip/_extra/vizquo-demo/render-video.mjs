/**
 * Renders the Vizquo 18s demo (vizquo-demo.html) to MP4, frame-exact:
 * the animation is a pure function of time, so each frame is rendered
 * synchronously at its exact 1/60s timestamp and captured via CDP
 * (headless is fine — no real-time loop needed).
 *
 *   node render-video.mjs            → vizquo-demo.mp4          (1920×1080, 16:9)
 *   node render-video.mjs --vertical → vizquo-demo-vertical.mp4 (1080×1920, 9:16)
 */
import { chromium } from '@playwright/test';
import { spawn } from 'node:child_process';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdirSync, writeFileSync, rmSync, readdirSync } from 'node:fs';
import ffmpegPath from 'ffmpeg-static';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..', '..'); // repo root (script lives in _extra/vizquo-demo/)
const HTML = resolve(ROOT, '_extra', 'vizquo-demo', 'vizquo-demo.html');
const TMP = resolve(ROOT, '.output', 'tmp-frames');

const VERT = process.argv.includes('--vertical');
const W = VERT ? 1080 : 1920;
const H = VERT ? 1920 : 1080;
const OUT = resolve(ROOT, '_extra', 'vizquo-demo', VERT ? 'vizquo-demo-vertical.mp4' : 'vizquo-demo.mp4');

const FPS = 60;
const DURATION = 18.0;
const TOTAL = Math.round(FPS * DURATION); // 1080

rmSync(TMP, { recursive: true, force: true });
mkdirSync(TMP, { recursive: true });

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: W, height: H } });
const cdp = await page.context().newCDPSession(page);

await page.goto('file://' + HTML.split('\\').join('/') + '?manual' + (VERT ? '&v' : ''));
await page.waitForFunction(() => typeof window.__vizquoRenderAt === 'function');
await page.evaluate(() => document.fonts.ready);
await page.waitForTimeout(250);

for (let i = 0; i < TOTAL; i++) {
  const t = i / FPS;
  await page.evaluate((s) => window.__vizquoRenderAt(s), t);
  const shot = await cdp.send('Page.captureScreenshot', {
    format: 'jpeg',
    quality: 92,
    fromSurface: true,
  });
  writeFileSync(
    join(TMP, String(i + 1).padStart(6, '0') + '.jpg'),
    Buffer.from(shot.data, 'base64'),
  );
  if (i % 180 === 0) console.log(`frame ${i}/${TOTAL} (t=${t.toFixed(1)}s)`);
}
await browser.close();

const frames = readdirSync(TMP).filter((f) => f.endsWith('.jpg')).length;
console.log(`captured ${frames} frames @ ${FPS}fps → ${(frames / FPS).toFixed(2)}s`);

const ff = spawn(
  ffmpegPath,
  [
    '-y',
    '-framerate', String(FPS),
    '-i', join(TMP, '%06d.jpg'),
    '-c:v', 'libx264',
    '-preset', 'medium',
    '-crf', '18',
    '-pix_fmt', 'yuv420p',
    '-movflags', '+faststart',
    OUT,
  ],
  { stdio: ['ignore', 'ignore', 'inherit'] },
);
await new Promise((r) => ff.on('close', r));
rmSync(TMP, { recursive: true, force: true });
console.log(`wrote ${OUT}`);
