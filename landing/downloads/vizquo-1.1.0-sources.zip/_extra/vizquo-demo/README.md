# Vizquo — 18s product demo video

**"See beyond the surface."** A designer/frontend-developer watches Vizquo
inspect a live webpage and reveal the hidden structure beneath it.

## Files

| File | What it is |
| --- | --- |
| `vizquo-demo.mp4` | Final video — 1920×1080 · 60 fps · 18.0s · H.264 (yuv420p) · ~4 MB |
| `vizquo-demo.html` | The animation itself — self-contained, plays in any browser (open the file) |
| `render-video.mjs` | Frame-exact renderer — reproduces the MP4 from the HTML |

## Timeline

| Time | Scene |
| --- | --- |
| 0.0–2.5s | Realistic browser on a polished SaaS site ("Lumen") — page settles in |
| 2.5–4.5s | Cursor inspects the hero heading — inspection frame, measurement ticks, ELEMENT / W / H labels |
| 4.5–7.0s | Vizquo side panel opens — font, color, line-height, spacing read live |
| 7.0–9.5s | Design-system view — colors (18×), type styles, spacing, radius, DETECTED badges |
| 9.5–12.0s | Asset extraction — SVG highlighted, pulled into an Extract card |
| 12.0–14.5s | The reveal — page annotations converge into the V-Lens |
| 14.5–18.0s | Brand frame — V-Lens · vizquo · SEE BEYOND THE SURFACE. · INSPECT · UNDERSTAND · EXTRACT · Open Source · Free |

Design language follows the video spec: `#050505` background, `#F5F5F7`
primary, `#7C5CFF` accent, glass panels, hairline borders, JetBrains Mono
instrumentation, natural eased cursor, no fake stats — every value is
plausible and clearly observed.

## Re-render

```bash
npm install --no-save ffmpeg-static   # portable ffmpeg (no global install)
node _extra/vizquo-demo/render-video.mjs
```

The renderer captures 1080 frames (60 fps × 18 s) frame-exact from the HTML
and encodes H.264. Edit `vizquo-demo.html` (timing, copy, site, cursor path)
and re-run to regenerate.

## Variants / sharing

- **Social (16:9)**: ready to post as-is.
- **Reels/TikTok (9:16)**: recompose, don't crop — scale the stage to
  `1080×1920` and stack scenes vertically (the HTML is structured to make
  this a layout change, not a rewrite).
- To export MP4 elsewhere without node: open `vizquo-demo.html`, screen-record
  the tab for 18s (OBS/QuickTime) — the animation auto-plays on load.

Served locally for marketing use; not part of the shipped product.
