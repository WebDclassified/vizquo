/**
 * Synthesizes the subtle Vizquo demo soundtrack as a stereo 16-bit WAV
 * (44.1kHz), with events placed on the exact animation timeline:
 *
 *   3.55s  cursor click (select element)
 *   4.3s   inspection confirm (frame + panel)
 *   7.3s   design-system transition (soft UI sweep)
 *   10.5s  asset highlight click
 *   10.9s  extraction whoosh (asset flies to panel)
 *   12.2s  reveal swell (annotations converge)
 *   14.6s  end-frame tone (quiet warm chord)
 *   18.0s  fade to silence
 *
 * Everything stays soft: gentle attacks, fast-decay percussives, and a
 * warm pad — no whooshes, no bangs, no gaming sounds. Works silently too.
 *
 * Run: node make-soundtrack.mjs
 */
import { writeFileSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SR = 44100;
const DUR = 18.0;
const N = Math.round(SR * DUR);

const L = new Float32Array(N);
const R = new Float32Array(N);

/* deterministic white noise (mulberry32) */
let seed = 0x9e3779b9;
const rnd = () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const noiseBuf = new Float32Array(N);
for (let i = 0; i < N; i++) noiseBuf[i] = rnd() * 2 - 1;

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/* envelope helpers */
const envA = (t, a) => clamp(t / a, 0, 1);                       // attack
const envR = (t, dur, r) => clamp((dur - t) / r, 0, 1);          // release
const expDecay = (t, k) => Math.exp(-k * t);                      // exponential tail

function mix(bufL, bufR, start, dur, gen, opts = {}) {
  const { pan = 0, gain = 1 } = opts;
  const s = Math.round(start * SR);
  const n = Math.round(dur * SR);
  const gL = gain * (pan <= 0 ? 1 : 1 - pan);
  const gR = gain * (pan >= 0 ? 1 : 1 + pan);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const v = gen(t, i);
    if (s + i >= N) break;
    L[s + i] += v * gL;
    R[s + i] += v * gR;
  }
}

/* ---------------- events ---------------- */

/* soft cursor click: short filtered noise tick + tiny low thump */
function click(t) {
  const a = envA(t, 0.0015), r = envR(t, 0.05, 0.05);
  const tick = noiseBuf[Math.floor(t * SR)] * Math.sin(Math.PI * Math.min(1, t / 0.012)) * 0.5;
  const thump = Math.sin(2 * Math.PI * 180 * t) * expDecay(t, 30);
  return (tick * expDecay(t, 90) * 0.22 + thump * 0.35) * a * r;
}

/* inspection confirm: two soft sine blips (major third, fast decay) */
function confirm(t) {
  const a = envA(t, 0.004), r = envR(t, 0.22, 0.18);
  const f1 = Math.sin(2 * Math.PI * 660 * t) * expDecay(t, 14);
  const f2 = Math.sin(2 * Math.PI * 880 * t) * expDecay(t, 18) * 0.7;
  const body = Math.sin(2 * Math.PI * 220 * t) * expDecay(t, 10) * 0.25;
  return (f1 + f2 + body) * 0.3 * a * r;
}

/* design-system sweep: rising filtered noise, one-pole lowpass */
function sweep(t, startHz, endHz, sharp) {
  const a = envA(t, 0.02), r = envR(t, 0.5, 0.22);
  const k = clamp(t / 0.5, 0, 1);
  const cutoff = startHz + (endHz - startHz) * k;
  const alpha = Math.exp(-2 * Math.PI * (SR / 2 - cutoff) / SR);
  const fc = clamp(cutoff / (SR / 2), 0, 0.95);
  const y = noiseBuf[Math.floor(t * SR)] * (1 - alpha) * Math.pow(fc, sharp);
  return y * 0.5 * a * r;
}

/* asset extraction: quick rising pitch blip (whoosh-less) */
function extract(t) {
  const a = envA(t, 0.008), r = envR(t, 0.3, 0.24);
  const f = 300 + 900 * Math.min(1, t / 0.18); // rising sweep 300→1200
  const w = Math.sin(2 * Math.PI * f * t);
  const shimmer = Math.sin(2 * Math.PI * f * 1.5 * t) * expDecay(t, 20) * 0.35;
  return (w * 0.4 + shimmer) * a * r * expDecay(t, 6);
}

/* reveal swell: very soft low pass-through */
function swell(t, dur) {
  const a = envA(t, 0.3), r = envR(t, dur, 0.5);
  const f = 110 + 60 * Math.min(1, t / 0.6);
  return (Math.sin(2 * Math.PI * f * t) * 0.5 + noiseBuf[Math.floor(t * SR)] * 0.12) * a * r;
}

/* end-frame tone: warm quiet chord (A2 · E3 · A3 · C#4), slow in/out */
function endTone(t) {
  const a = envA(t, 1.2), r = envR(t, 3.4, 2.2);
  const freqs = [110, 164.81, 220, 277.18];
  let v = 0;
  for (const f of freqs) v += Math.sin(2 * Math.PI * f * t) * (f > 200 ? 0.32 : 0.45);
  v += Math.sin(2 * Math.PI * 55 * t) * 0.5; // sub root
  v *= 0.22;
  const shimmer = noiseBuf[Math.floor(t * SR)] * 0.03 * (0.5 + 0.5 * Math.sin(2 * Math.PI * 0.3 * t));
  return (v + shimmer) * a * r;
}

/* very quiet room tone throughout (ties the track together) */
function room(t) {
  const edge = envA(t, 1.5) * envR(t, DUR, 1.8);
  return noiseBuf[Math.floor(t * SR)] * 0.012 * edge;
}

/* ---------------- timeline ---------------- */
mix(L, R, 0, DUR, room, { gain: 1 });

mix(L, R, 3.55, 0.05, click, { gain: 0.85, pan: -0.15 });
mix(L, R, 4.3, 0.22, confirm, { gain: 0.6, pan: 0.1 });
mix(L, R, 7.3, 0.5, (t) => sweep(t, 400, 2400, 2.2), { gain: 0.5, pan: 0.2 });
mix(L, R, 10.5, 0.05, click, { gain: 0.7, pan: 0.15 });
mix(L, R, 10.9, 0.3, extract, { gain: 0.55, pan: -0.2 });
mix(L, R, 12.2, 1.2, (t) => swell(t, 1.2), { gain: 0.5 });
mix(L, R, 14.6, 3.4, endTone, { gain: 0.85 });

/* ---------------- master ---------------- */
let peak = 0;
for (let i = 0; i < N; i++) peak = Math.max(peak, Math.abs(L[i]), Math.abs(R[i]));
const norm = 0.6 / peak; // ~ -4.4 dBFS headroom
for (let i = 0; i < N; i++) {
  L[i] *= norm; R[i] *= norm;
}

/* ---------------- write WAV (16-bit stereo) ---------------- */
const dataLen = N * 4;
const buf = Buffer.alloc(44 + dataLen);
buf.write('RIFF', 0); buf.writeUInt32LE(36 + dataLen, 4); buf.write('WAVE', 8);
buf.write('fmt ', 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(2, 22);
buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 4, 28); buf.writeUInt16LE(4, 32); buf.writeUInt16LE(16, 34);
buf.write('data', 36); buf.writeUInt32LE(dataLen, 40);
for (let i = 0; i < N; i++) {
  const s = 44 + i * 4;
  buf.writeInt16LE(Math.round(clamp(L[i], -1, 1) * 32767), s);
  buf.writeInt16LE(Math.round(clamp(R[i], -1, 1) * 32767), s + 2);
}

const OUT = resolve(__dirname, 'soundtrack.wav');
writeFileSync(OUT, buf);
console.log(`wrote ${OUT} — ${DUR}s @ ${SR}Hz, peak ${(peak * norm).toFixed(3)}`);
