# Vizquo — 5-Minute Loom Recording Plan & Narration Script

> Everything below is verified against this repository (README.md, ARCHITECTURE.md,
> TESTING.md, HARDENING_REPORT.md, DECISIONS.md, CHANGELOG.md, engine/, ai/, export/,
> wxt.config.ts, tests/). Nothing is invented. Where a number can drift, the script
> tells you to show it live instead of quoting it.

- **Product**: Vizquo 1.0.0 — browser extension that turns any live webpage into a
  visual blueprint (CSS, design tokens, assets, responsive behavior, reusable patterns),
  with every value traced to its source and labeled with confidence.
- **Stack (all in package.json)**: WXT (MV3, cross-browser) · SolidJS + Kobalte ·
  UnoCSS · Dexie/IndexedDB · @webext-core/messaging (typed RPC) · Comlink workers ·
  css-tree · culori · fflate · Vitest + Playwright + custom Chrome torture harness.
- **Verified headline numbers**: 437 unit tests across 49 files (CHANGELOG 1.0.0) ·
  33/33 torture scenarios in real Chrome · 23/23 live-site probe · 7 desktop browsers ·
  250k-node DOM scanned in ~21.6 s without freezing · zero network requests by default.

---

## 1. The story (why this project, in one sentence)

**Problem**: Designers and frontend devs burn hours asking per-element questions —
"what font is that? what exact color? where does this spacing come from? how does this
behave at 390px?" — because DevTools answers them one tab at a time and remembers nothing.

**What Vizquo does differently**: one side panel answers all of those against the live
page in seconds, stores them as a browsable, exportable library — and, uniquely,
**labels every value Detected / Derived / Inferred and honestly reports truncated scans
and inaccessible resources**. It is an instrument, not an oracle.

**Why it proves engineering ability (not just UI)**: a three-context pipeline (content
script → Comlink worker → panel) that survives hostile pages; a privacy architecture
where the API key never leaves the background worker; a deterministic 33-scenario
torture suite that found and fixed 5 real P1/P2 bugs, each with a permanent regression
test (TOR-028, TOR-030, TOR-031; BUG-H-001…005).

---

## 2. Demo setup (do this before recording)

```sh
npm install
npm run build          # → .output/chrome-mv3
```

1. Chrome → `chrome://extensions` → Developer mode → **Load unpacked** → `.output/chrome-mv3`.
2. Pin Vizquo. Shortcuts used on camera (from wxt.config.ts):
   `Ctrl+Shift+Y` open panel · `Ctrl+Shift+E` inspect mode · `Ctrl+Shift+D` Designer⇄Engineer ·
   `Ctrl+Shift+S` screenshot · `Ctrl+K` command palette · omnibox `viz scan`.
3. Record at 1920×1080, browser maximized, ~125% page zoom on the demo tab so panel
   text is readable in the video.
4. Pre-warm: open the demo page and run one scan before recording so the L2/L3 cache
   makes the on-camera scan feel instant (the panel honestly shows "cached").

**The demo page: Vizquo's own landing page**
`https://webdclassified.github.io/vizquo/landing/` (served from `landing/index.html` in this repo —
the README literally markets it as "the product inspecting itself").

Why it is the right page — it contains everything Vizquo extracts:
- A real design system: emerald accent `#3E8E67`, derived mint/amber/rose signals,
  Inter + JetBrains Mono, a 4-step radius scale (8/12/16/24px), liquid-glass materials,
  ambient radial fields, a 3-step "How it works" component row, buttons, cards, a mock
  browser frame, counters, and responsive breakpoints.
- It is local/static → clean, fast scan, no CSP blocks, no tracking noise on camera.
- The self-referential framing ("the tool inspecting its own marketing site") is the
  strongest possible 5-second hook.

**Backups** (only if you want one cutaway): **Wikipedia** (rich typography/hierarchy,
verified 0-error in HARDENING_REPORT) and **vercel.com** (Tailwind v4 arbitrary classes —
the exact page class that broke selector generation before the TOR-028 fix; great for
one sentence about real-world hardening). Do **not** use YouTube on camera — its strict
CSP triggers the main-thread fallback path, which is a great story in the script but a
19.5-second wait on video.

---

## 3. Shot-by-shot recording plan (with on-screen actions)

| # | Time | Screen action | Talking point |
|---|------|---------------|---------------|
| 1 | 0:00–0:20 | Show the landing page, idle | Hook: the problem |
| 2 | 0:20–0:50 | Press `Ctrl+Shift+Y` → panel opens, onboarding already done | What Vizquo is; connection card |
| 3 | 0:50–1:00 | Press `Ctrl+Shift+E` (or right-click → Inspect with Vizquo) → hover hero CTA | Inspect mode, measure lines, lock |
| 4 | 1:00–1:40 | Click **Scan** in the panel; let sections stream in; open **Design** tab | Design DNA + consistency score + confidence labels |
| 5 | 1:40–2:20 | Back in **Inspect** tab with element locked; scroll Inspector panel; press `Ctrl+Shift+D` twice | Cascade/specificity, variable chains, box model, Designer⇄Engineer |
| 6 | 2:20–2:50 | Design tab → click a color chip's "find instances" → page highlights; switch to **Assets** tab, select 2 SVGs → **Export ZIP** | Find-instances + asset pipeline |
| 7 | 2:50–3:20 | **Create** tab on the locked button → code viewer React → HTML; then Export center → tokens as CSS + Figma Tokens | Codegen + token export matrix |
| 8 | 3:20–3:50 | **Analyze** tab → a11y finding → click to highlight on page; **Time Machine** slider to 375px | Audits with exact WCAG math + iframe emulation |
| 9 | 3:50–4:30 | Settings → AI section → toggle on → consent dialog shows payload summary (do NOT need a key) | The AI architecture story |
| 10 | 4:30–5:00 | IDE: run `npm run test` (scroll output), show `scripts/torture.mjs` scenario list; back to panel | Testing evidence + close |

Timing discipline: this plan is paced for ~150 wpm narration. Rehearse segment 9 once —
it is the densest. If you run long, cut segment 6's ZIP export, never segment 9 or 10.

---

## 4. Narration script (TTS-ready, ~740 words ≈ 5:00)

> Read numbers exactly as written. Lines in [brackets] are recording directions, not narration.

### Segment 1 — Hook (0:00–0:20)
[Screen: landing page, cursor idle]

> If you've ever inspected a website to answer a simple question — what font is this,
> what exact color is that button, where does this spacing come from — you know the
> routine: DevTools, one element at a time, and every answer forgotten the moment you
> close the tab. I built Vizquo to fix that. And the page you're looking at is Vizquo's
> own landing page — so for the next five minutes, the product will inspect itself.

### Segment 2 — What it is (0:20–0:50)
[Screen: press Ctrl+Shift+Y, panel slides open; point at connection card]

> Vizquo is a Manifest V3 browser extension built with WXT and SolidJS. It turns any
> live webpage into a visual blueprint — CSS, design tokens, assets, responsive
> behavior, and reusable patterns — collected in one side panel, and saved to a local
> library you can revisit. Everything is local-first: scans live in IndexedDB in your
> browser, and the extension makes zero network requests until you explicitly opt into
> AI. Let me show you the core workflow.

### Segment 3 — Inspect mode (0:50–1:00)
[Screen: Ctrl+Shift+E, hover the "Get started" button; measure lines appear; click to lock]

> Press Control-Shift-E, and the page becomes measurable — hover shows the element
> framed with live dimensions. Click, and it's locked for deep inspection.

### Segment 4 — Scan + Design DNA (1:00–1:40)
[Screen: click Scan; sections stream in — colors, then typography, scales, components;
then open the Design tab; point at consistency score and a "Detected" badge]

> One click scans the page. The DOM walk is time-sliced and capped — twelve thousand
> nodes walked, four thousand sampled — and larger pages are honestly flagged as
> truncated, never silently cut. Heavy analysis runs off-thread in a Comlink worker,
> and results stream into the panel as they finish — colors first, then typography.
> This is the Design DNA: colors clustered perceptually in OKLCH with inferred roles,
> the type hierarchy, and the spacing, radius, and shadow scales — plus a design
> consistency score from zero to one hundred. And this is the principle the whole
> product is built on: every value carries a confidence label — Detected, Derived, or
> Inferred. Vizquo tells you what it knows, and what it only thinks.

### Segment 5 — Inspector depth (1:40–2:20)
[Screen: Inspect tab on the locked button; scroll through cascade rows; press Ctrl+Shift+D
to switch to Engineer mode and back; point at the source file:line trace]

> For any element, the inspector resolves the full CSS cascade with css-tree —
> specificity as the correct four-tuple, which rule won, which rules were overridden,
> and the exact stylesheet and line each value came from. You get the variable chain,
> the box model, and the DOM tree. One more thing I care about: this toggle switches
> the entire panel between Designer mode — plain language — and Engineer mode, raw
> values, no extra clicks. Same data, two audiences, instant switch.

### Segment 6 — Find + extract (2:20–2:50)
[Screen: Design tab → find instances of the accent color → page highlights; Assets tab →
select two SVGs → Export ZIP → downloads tray shows vizquo-assets.zip]

> Every token is actionable. Find-instances highlights every element using this color —
> right on the page. The asset pipeline classifies images, SVGs, and backgrounds, and
> bulk-exports them as a ZIP from the background worker — with CORS failures recorded
> per asset in the metadata, never silently dropped. SVGs can even be converted to
> React components.

### Segment 7 — Codegen + token export (2:50–3:20)
[Screen: Create tab on the locked button → React code → switch to HTML; then Export
center → CSS tokens, then Figma Tokens format]

> The Create tab generates component code — React, Vue, Svelte, HTML, or Tailwind —
> from the real computed styles, with browser defaults filtered and unresolved variable
> chains refused, so the output matches what you actually see. Design tokens export to
> CSS, SCSS, Tailwind, JSON, TypeScript, Figma Tokens, and Style Dictionary.

### Segment 8 — Audits + Time Machine (3:20–3:50)
[Screen: Analyze tab → click a contrast finding → element highlights on page; then
Time Machine slider → drag to 375px]

> The Analyze tab audits the page — WCAG contrast is computed with exact
> relative-luminance math, and unparsable colors are skipped, never fabricated into
> fake pass-or-fail results. Every finding anchors to its element. And the Time
> Machine emulates any viewport width in a real same-origin iframe, so media queries
> genuinely re-evaluate — at 375 pixels, you see exactly what a phone sees.

### Segment 9 — The AI story (3:50–4:30)
[Screen: Settings → AI → toggle on → consent dialog with payload summary visible; hover
the summary text; do not need a key]

> AI is optional, and this is where the engineering gets serious. It's off by default.
> Enabling it shows you a consent gate that lists, byte for byte, exactly what will be
> sent — text bounded to two hundred characters, HTML snippets sanitized to tag and
> class only, input values and data attributes excluded by construction. The API key
> lives only in the background service worker — it never touches the content script or
> the page, and a torture scenario proves page-world JavaScript has zero runtime
> surface to reach it. Six providers are supported — OpenRouter, OpenAI, Anthropic,
> Gemini, Groq, and a fully local Ollama that never leaves your machine.

### Segment 10 — Evidence + close (4:30–5:00)
[Screen: IDE — run `npm run test`; scroll; then show scripts/torture.mjs TOR list; back to panel]

> Finally — reliability. [Point at test output.] Four hundred thirty-seven unit tests.
> [Point at torture.mjs.] And a deterministic torture suite that drives the built
> extension through thirty-three hostile scenarios in real Chrome — quarter-million-node
> DOMs, mutation storms, strict CSP, shadow DOM, prompt injection. It found five real
> bugs, including silently wrong element selectors, and every fix shipped with a
> permanent regression test. Vizquo scans honestly, explains completely, and never
> claims more than it observed. That's the standard I hold my engineering to.
> Thanks for watching.

---

## 5. Verified claim sheet (say nothing that isn't on this list)

| Claim in script | Source of truth |
|---|---|
| MV3, WXT + SolidJS, cross-browser (7 desktop browsers) | package.json, README badges, wxt.config.ts |
| Scan caps 12k walk / 4k sampled, honest `truncated` flag | `engine/scan/scan.ts` (MAX_WALK_ELEMENTS, MAX_SAMPLES), TOR-001 |
| Comlink worker + CSP main-thread fallback | `engine/analysis/orchestrator.ts` (probeWorkerHealth), ARCHITECTURE.md |
| OKLCH clustering, roles, consistency score 0–100 | engine/tokens/, tests/color, roles, consistency |
| 4-tuple specificity, css-tree, source file:line traces | engine/css/specificity.ts, DECISIONS.md Phase 2 |
| Designer⇄Engineer instant switch (Ctrl+Shift+D) | README, wxt.config.ts commands |
| Find-instances highlight on page | engine/tokens/find.ts, orchestrator.findInstances |
| Asset ZIP in background, per-asset failure metadata | entrypoints/background.ts EXPORT_ASSETS, export/assets-zip.ts |
| SVG→React conversion | export/svg-react.ts, tests/svg-react.test.ts |
| Codegen React/Vue/Svelte/HTML/Tailwind, no bare `var()` | export/codegen.ts, tests/codegen.test.ts |
| Token export: CSS/SCSS/Tailwind/JSON/TS/Figma Tokens/Style Dictionary | export/tokens.ts, tests/tokens-export.test.ts |
| WCAG exact luminance math, unparsable → skipped | engine/accessibility/audit.ts, DECISIONS.md Phase 5 |
| Time Machine: same-origin iframe, honest `emulated: false` | engine/responsive/time-machine.ts, DECISIONS.md Phase 5 |
| AI off by default, consent gate shows exact payload | ai/gate.ts, ai/prompts.ts (MAX_TEXT 200, snippet 160, value/data-* stripped) |
| Key isolated in background worker only | background.ts AI_EXPLAIN, TOR-031, DECISIONS.md "keyless by construction" |
| 6 providers: OpenRouter/OpenAI/Anthropic/Gemini/Groq/Ollama | ai/registry.ts |
| 437 unit tests / 49 files / 33 torture scenarios | CHANGELOG.md 1.0.0; `npm run test`; scripts/torture.mjs |
| 5 real bugs found by torture, all regression-tested | HARDENING_REPORT.md (BUG-H-001…005, TOR-028/030/031) |
| 250k-node scan ~21.6 s; YouTube 19.5 s under strict CSP | HARDENING_REPORT.md §8 (say "about twenty seconds", don't quote decimals) |
| Zero network requests until AI opt-in | PRIVACY.md, TOR-012, README |

**Do NOT claim on camera** (not verified in repo): user counts, store listings,
performance benchmarks beyond the hardening report, "AI writes code", or any metric
from the landing page's marketing counters as if they were engineering results.

## 6. If something misbehaves on camera

- Scan feels slow → the page was cold; say "first scan computes, re-scans are served
  from the content-hash cache" and let it finish — honest is on-brand.
- AI section: you never need a working key. The consent gate + payload summary IS the demo.
- Time Machine shows "emulated: false" on some sites → that's the honest fallback
  (X-Frame-Options); say so, or demo on the landing page where framing works.
- Anything crashes → delete `.output`, `npm run build` again, re-record; do not
  improvise narration around a broken state.
