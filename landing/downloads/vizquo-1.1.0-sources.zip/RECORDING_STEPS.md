# Vizquo — Full Step-by-Step Recording Guide

Companion to `LOOM_RECORDING_PLAN.md` (which has the narration script §4 and claim
sheet §5). This file is the *operator's manual*: every click, in order, with timing.
All UI names below are verified against the actual panel code (NavTabs, DesignPanel,
AssetsPanel, AnalyzePanel, ElementDetail, SettingsScreen).

**Demo page**: `https://webdclassified.github.io/vizquo/landing/` — open it, keep it the
active tab for the whole video. Do not switch tabs until Segment 10.

---

## Part A — One-time setup (before recording day)

### A1. Build and load the extension
```sh
npm install
npm run build        # → .output/chrome-mv3
```
1. Chrome → `chrome://extensions` → enable **Developer mode** (top-right).
2. **Load unpacked** → select `.output/chrome-mv3`.
3. Click the Extensions puzzle icon → **pin Vizquo** to the toolbar.

### A2. Prime the panel state (so onboarding never appears on camera)
1. Open the landing page, click the Vizquo toolbar icon → side panel opens.
2. Complete the **onboarding tour** once (it never reappears — verified by the E2E suite).
3. In the panel header, click the **theme icon** once → set theme to **dark** (matches
   the landing page's near-black palette; the video reads as one continuous surface).
4. Panel width: drag Chrome's side-panel edge to ~380–400 px so all text is legible.
5. Keep the landing page open. Close the panel. State is persisted — reopening on
   camera will show a clean, connected panel with no tour.

### A3. Verify shortcuts (chrome://extensions/shortcuts)
- `Ctrl+Shift+Y` — open side panel
- `Ctrl+Shift+E` — toggle inspect mode
- `Ctrl+Shift+D` — Designer ⇄ Engineer
- `Ctrl+K` — command palette (inside panel)

### A4. Warm the cache
On the landing page: open panel → **Design** tab → click **Scan page** once, let it
finish. (Re-scans are served from the content-hash cache and the panel shows it —
this makes the on-camera scan feel instant.)

### A5. Recording tools
- **Video**: OBS (or Loom desktop). Capture: 1920×1080, 30 or 60 fps, capture the
  Chrome window (not full screen). Windows fallback: `Win+Alt+R` (Xbox Game Bar).
- **Zoom**: landing page at **110–125%** (`Ctrl` + `+`) so panel + page text is readable.
- **Cursor**: enable cursor highlight in your recorder — you click a lot.
- **Audio**: none while recording screen. Narration is added per-segment with TTS
  (workflow in Part D).

---

## Part B — The recording itself (9 shots, ~5:00 of screen action)

> Rehearse Part B twice with a timer before the real take. Between shots, you may cut
> — each shot is edited independently in Part D.

---

### SHOT 1 — Hook (record 0:25 of footage, use ~0:20)
**Screen**: landing page only. Slowly scroll down ~400 px, then back to top. Rest the
cursor near the "Get started"-style hero area. Nothing else.
**Mistake to avoid**: do not touch the panel yet; this shot is just the website.

---

### SHOT 2 — Panel opens (record 0:35, use ~0:30)
1. Click the **Vizquo toolbar icon** → side panel slides open on the right.
2. Pause 2 s so the viewer reads the header (logo, palette, shortcuts, theme, settings icons).
3. Move cursor over the panel — the **connection card** should show it is connected to
   the landing page.
4. Optional flourish: press **Ctrl+K**, type `scan`, press **Esc** (shows the command
   palette exists — do NOT run the scan yet).
**Talking point**: MV3 extension, WXT + SolidJS, local-first, zero network requests.

---

### SHOT 3 — Inspect mode + lock (record 0:20, use ~0:10)
1. Click on the **page** first (so focus is on the landing tab, not the panel).
2. Press **Ctrl+Shift+E** → inspect mode turns on. The page is now hoverable with the
   Vizquo overlay.
3. Hover down the page: heading → subheading → a card → then **hover the nav button /
   CTA button** ("Sign in" or the mock CTA "Get started" inside the browser-frame demo).
   Measure lines and dimensions are visible.
4. **Click** to lock the element.
**Do not** narrate cascade details yet — that's Shot 5.

---

### SHOT 4 — Scan + Design DNA (record 0:50, use ~0:40)
1. Back in the panel: click the **Design** tab.
2. Click the primary **Scan page** button (top of the Design DNA card).
3. Do nothing for the first 2–3 seconds — sections stream in progressively
   (colors → typography → spacing → components). Scroll slowly as they land.
4. Stop on:
   - the **color roles** row (hover one chip for a second),
   - the **typography hierarchy**,
   - the **Design consistency score** (0–100),
   - one **confidence badge** (Detected / Derived / Inferred) — hover it.
5. Scroll the *page* slightly to show click-to-highlight context (optional).

---

### SHOT 5 — Inspector depth + Designer⇄Engineer (record 0:45, use ~0:40)
1. Click the **Inspect** tab — the element locked in Shot 3 is still shown.
2. Slowly scroll through the inspector: computed styles, **which rule won / overridden**,
   the **source trace** (stylesheet + line), the **variable chain**, the **box model
   diagram**. Pause ~1 s on the source trace.
3. Click the **Engineer** segment in the nav bar (top-right of the panel — next to the
   tabs). Pause. Click **Designer** back. (Instant switch, no rescan — that's the point.)
4. Optional: click the **"Why?"** button in the element detail — the AI dialog opens;
   click **Cancel / close** (this plants the seed for Shot 8 — you are NOT sending a
   request yet).

---

### SHOT 6 — Find instances + asset ZIP (record 0:35, use ~0:30)
1. **Design** tab → find a color chip (ideally the emerald accent) → click the small
   **find-instances icon** on the chip (tooltip: "Find instances on the page").
2. Point the cursor at the **page**: matching elements get highlight outlines.
3. Click the **Assets** tab → let the grid populate → select **2–3 SVG icons/logos**
   (the panel's own SVG assets on the landing page are good).
4. Click **Export ZIP** (button label shows the count, e.g. "Export ZIP (3)").
5. Show the browser download bubble briefly: **vizquo-assets.zip**.

---

### SHOT 7 — Codegen + token export (record 0:35, use ~0:30)
1. **Create** tab (element from Shot 3 must still be locked — if you lost it, redo
   Shot 3's lock first, this is one cut-friendly reason to rehearse).
2. The code viewer shows generated **React** — scroll through it slowly.
3. Switch the framework dropdown/segment to **HTML** — show it change.
4. Below/side: the **token export** — choose **CSS** (show custom properties), then
   switch the format to **Figma Tokens** (show the JSON shape).
5. Optional: click **Download** on one of them — a real file lands in the tray.

---

### SHOT 8 — Audits + Time Machine (record 0:35, use ~0:30)
1. **Analyze** tab → findings grouped by severity.
2. Click one **contrast finding** → the element highlights on the page (cursor follows).
3. Scroll to the **Responsive** section → the **Time Machine** slider.
4. Drag the slider to **375 px** → the emulated preview re-renders. Hold 2 s.
5. Drag back to a desktop width (~1280) so the page state ends clean.

---

### SHOT 9 — AI privacy gate (record 0:45, use ~0:40)
**No API key is needed for this shot — the consent gate IS the demo.**
1. Panel header → click the **Settings icon** (gear, top-right).
2. Scroll to the **AI** section.
3. Toggle AI **on** → the **consent dialog** appears showing the exact payload
   summary ("The element <tag id class role>… No attribute values beyond these are
   sent; input values and data-* attributes are excluded.").
4. Hover the payload text slowly — this is the money shot of the privacy story.
5. Close the dialog (do not proceed to a request).
6. Optional single sentence: mention the six providers (OpenRouter, OpenAI, Anthropic,
   Gemini, Groq, Ollama-local) from the provider picker — show the dropdown briefly.

---

### SHOT 10 — Evidence + close (record 0:35, use ~0:30)
**This is the only shot off the landing page.**
1. Switch to your **IDE/terminal** (pre-opened at the repo root).
2. Run `npm run test` (or scroll a pre-run output) — show the **437 tests** passing line.
3. Open `scripts/torture.mjs` → scroll the TOR- scenario list quickly (TOR-001 … TOR-031).
4. Cut back to Chrome: landing page + panel on the Design tab, consistency score visible.
5. End on a still frame for 2 s. Stop recording.

---

## Part C — Shot → narration mapping

| Shot | Use | Narration segment (LOOM_RECORDING_PLAN.md §4) |
|------|-----|-----------------------------------------------|
| 1 | 0:00–0:20 | Segment 1 — Hook |
| 2 | 0:20–0:50 | Segment 2 — What it is |
| 3 | 0:50–1:00 | Segment 3 — Inspect mode |
| 4 | 1:00–1:40 | Segment 4 — Scan + Design DNA |
| 5 | 1:40–2:20 | Segment 5 — Inspector depth |
| 6 | 2:20–2:50 | Segment 6 — Find + extract |
| 7 | 2:50–3:20 | Segment 7 — Codegen + tokens |
| 8 | 3:20–3:50 | Segment 8 — Audits + Time Machine |
| 9 | 3:50–4:30 | Segment 9 — AI privacy gate |
| 10 | 4:30–5:00 | Segment 10 — Evidence + close |

If a shot runs long in the edit, trim from Shot 6 (ZIP download) — never from 9 or 10.

---

## Part D — Assembling with TTS narration

1. **Edit the picture first**: cut the 10 shots to the durations in Part C. No audio.
2. Generate TTS per segment (one audio file per narration segment, not one giant file —
   per-segment files make timing fixes painless). Read punctuation carefully; the script
   is written for it.
3. Target pace ≈ 150 wpm. Check each segment's audio length against its slot:
   - Segment audio longer than the slot → trim the picture (cut hover pauses), not the words.
   - Segment audio shorter → stretch the picture (add a 1–2 s hold on the relevant UI).
4. Lay the segments on the timeline at Part C's timestamps.
5. Final checks:
   - Total duration ≤ 5:10 (rubric says ~5 minutes).
   - Every number spoken matches the claim sheet (LOOM_RECORDING_PLAN.md §5).
   - Zero dead air over 2 s.
   - Panel text legible at 100% zoom on the final render (watch it once at 1× speed).

---

## Part E — Contingencies (while recording)

| Problem | Action |
|---|---|
| Scan is slow / cold | Let it finish and say nothing — the edit cuts it. Never fake it. |
| Lost the locked element in Shot 7 | Re-lock: Ctrl+Shift+E → click the button → Create tab. (Cut-friendly.) |
| Find-instances highlights nothing | You clicked a color used once — pick the accent color chip instead. |
| Export ZIP button disabled | Nothing selected — select assets first (the button label shows the count). |
| Time Machine shows "emulated: false" | The site forbids framing — say it's the honest fallback and demo at a width that works, or skip to audits. |
| AI consent dialog doesn't appear | The toggle is already on from a previous session — toggle off, then on again. |
| Panel shows stale/cached badge | Good — that's the L2 cache being honest. Leave it, it's a talking point. |
| Anything crashes | `rm -rf .output && npm run build`, reload the unpacked extension, redo the affected shot only. |

---

## Part F — Final pre-flight checklist (recording day)

- [ ] Extension loaded, pinned, onboarding done, theme dark, panel ~400 px
- [ ] Landing page open at ~110–125% zoom, scrolled to top
- [ ] Cache warmed (one scan done earlier, panel closed)
- [ ] Shortcuts verified: Ctrl+Shift+Y / E / D, Ctrl+K
- [ ] Recorder: 1080p, window capture, cursor highlight, ~60 fps
- [ ] IDE pre-opened at repo root (Shot 10), `npm run test` works
- [ ] Downloads folder visible for the ZIP shot
- [ ] Timer/rehearsal done twice
- [ ] Downloads folder cleaned (so the new vizquo-assets.zip is the only one on camera)
- [ ] Browser notifications muted (`chrome://settings` → notifications off) — no popups on camera
